# Modular KDE Plasma Manager configuration

This package **replaces only the original `home/kde/kwin.nix`** and adds a
new `home/kde/plasma-modules/` directory. Your existing `home/kde/default.nix`,
`floating-panel.nix`, and other modules are not replaced or removed.

## Installation

1. Copy `kwin.nix` into `~/nixos/home/kde/kwin.nix`.
2. Copy the **entire** `plasma-modules` folder to `~/nixos/home/kde/plasma-modules/`.
3. Keep your existing `./kwin.nix` import in `home/kde/default.nix` **unchanged**.
4. Stage the new files for flake evaluation:
   `git add home/kde/kwin.nix home/kde/plasma-modules/`
5. Run `nh os build`, and if it succeeds, `nh os switch`.

Do not also import the original giant module or `plasma-modules/default.nix`
separately; doing so could create duplicate definitions.

## Where to edit settings

| File | Contents |
| --- | --- |
| `plasma-modules/plasma.nix` | Enable Plasma Manager |
| `plasma-modules/appearance.nix` | Colors, theme defaults, fonts, icons, splash screen |
| `plasma-modules/wallpapers.nix` | Per-monitor desktop images, lock screen, history |
| `plasma-modules/kwin.nix` | KWin, native layouts, window rules |
| `plasma-modules/karousel.nix` | Karousel script, shortcuts, readable window rules |
| `plasma-modules/shortcuts.nix` | Other shortcuts |
| `plasma-modules/input.nix` | Keyboard and mouse |
| `plasma-modules/applications.nix` | Dolphin, Kate, Spectacle |
| `plasma-modules/services.nix` | KDE background services and miscellaneous |
| `plasma-modules/kate-session.nix` | Saved Kate session (large state export) |

## Notes

- The 17 Karousel rules remain identical and in the same order.
- Active KDE colors, cursor/icon theme, native tiling layouts and rules are unchanged.
- Wallpaper screen paths are preserved, including the current MONITOR2/Permanent/old-pc.png.
- The original hardcoded Ghostty store path, timestamps, and Kate session are retained.
- The existing Steam `kwinrulesrc` rule has no `noborder` setting; it is preserved, not repaired.
- This reorganization does **not** add the wallpaper hot-reload activation hook
  mentioned previously, because it was not present in the input file.
- Only settings from the supplied file are included; pre-existing
  `floating-panel.nix` or other modules are not modified.
- Full NixOS/Home Manager evaluation is not available in this environment;
  verify with `nh os build` before switching.

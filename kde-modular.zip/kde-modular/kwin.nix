# Compatibility shim: keep your existing ./kwin.nix import unchanged.
# Edit the focused modules in ./plasma-modules/ instead.
{ ... }:
{
  imports = [ ./plasma-modules ];
}

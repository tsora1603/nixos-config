# Enable Plasma Manager once.
# Split from kwin(2).nix without changing configuration values.
{ ... }:
{
  programs.plasma = {
    # Plasma Manager
    enable = true;
  };
}

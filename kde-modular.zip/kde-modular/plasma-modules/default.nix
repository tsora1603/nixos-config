# All settings split from the previous monolithic home/kde/kwin.nix.
# Import this directory only once.
{ ... }:
{
  imports = [
    ./plasma.nix
    ./appearance.nix
    ./wallpapers.nix
    ./kwin.nix
    ./karousel.nix
    ./shortcuts.nix
    ./input.nix
    ./applications.nix
    ./services.nix
    ./kate-session.nix
  ];
}
